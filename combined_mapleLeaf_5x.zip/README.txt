by 50UR4V Sep '21
permalink: https://forum.openhdfpv.org/t/panelized-maple-leaf-antennae/572

When ordering maple leaf antennae it is often much easier (and cheaper) to order them in bulk in panelized form.

Here are the points to remember: (taking pcbway /jlcpcb as examples)

1. Upload the entire zip file in the upload section.
2. Choose the PCB thickness to be 1mm (very important to keep the tuning of the antenna)
3. Choose single PCB (not panelized by customer or company)
4. Leave the rest of the settings at default.
5. Normally each batch should get you 5x5=25pieces. (Share it with your local community members :grinning_face_with_smiling_eyes:)
6. Remember to order the appropriate antenna connector. (I prefer to solder directly the end of a sma / U.fl pigtail)
